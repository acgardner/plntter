class AEKF:
    """
    Placeholder class for Additive EKF
    """
    def predict(self):
        pass
    def update(self):
        pass

class MEKF:
    """
    Placeholder class for Multiplicative EKF
    """
    def predict(self):
        pass
    def update(self):
        pass

class UKF:
    """
    Placeholder class for Unscented KF
    """
    def predict(self):
        pass
    def update(self):
        pass
